<powershell>
  # Escape any variables that are not passed by Terraform ($$)
  $hostname = "${hostname}"

  # Set NODENAME Env Var
  [Environment]::SetEnvironmentVariable("NODENAME", $hostname)
  [Environment]::SetEnvironmentVariable("NODENAME", $hostname, [System.EnvironmentVariableTarget]::Machine)

  # Add hosts Entry	
  # This is needed so the pt_pia status checking works	
  #   The cloned instance does not update hosts, so we do it ourselves
  $$fqdn="$(facter fqdn)"
  $$ipaddr="$(facter ipaddress)"
  add-content -path c:\windows\system32\drivers\etc\hosts -value "127.0.0.1 $${fqdn}"	
  add-content -path c:\windows\system32\drivers\etc\hosts -value "$${ipaddr} $${fqdn}"	

  # Add java to PATH	
  # This also fixes the pt_pia status checking script	
  $$path="$${env:PATH}"
  $$jdk_home="$(hiera jdk_location -c C:\psft\dpk\puppet\hiera.yaml)"	
  [Environment]::SetEnvironmentVariable("PATH", "$${path};$${jdk_home}\bin")
  [Environment]::SetEnvironmentVariable("PATH", "$${path};$${jdk_home}\bin", [System.EnvironmentVariableTarget]::Machine)	

  # Start Tuxedo domains	
  psa start app	
  psa start prcs
<powershell>