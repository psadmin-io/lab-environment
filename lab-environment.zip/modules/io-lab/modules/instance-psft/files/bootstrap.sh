# TODO add users, groups, etc
 sudo groupadd -r -g 30002 psft
 sudo groupadd -r -g 30003 appinst
 sudo groupadd -r -g 30004 oinstall
 sudo groupadd -r -g 30005 dba
 #
 sudo adduser esadm1 --home /u01/app/oracle/product/home/esadm1 -u 20006
  sudo usermod -a -G psft esadm1
  sudo usermod -a -G oinstall esadm1
 sudo adduser oracle2 --home /u01/app/oracle/product/home/oracle2 -u 20005
  sudo usermod -a -G dba oracle2
  sudo usermod -a -G oinstall oracle2
 sudo adduser psadm1 --home /u01/app/oracle/product/home/psadm1 -u 20002
  sudo usermod -a -G psft psadm2
  sudo usermod -a -G oinstall psadm2
 sudo adduser psadm2 --home /u01/app/oracle/product/home/psadm2 -u 20003
  sudo usermod -a -G psft psadm1
  sudo usermod -a -G oinstall psadm1
 sudo adduser psadm3 --home /u01/app/oracle/product/home/psadm3 -u 20004
  sudo usermod -a -G psft psadm3
  sudo usermod -a -G appinst psadm3 

# mount file system of volume
sudo mkdir -p /u01/app/oracle/product
echo '/dev/oracleoci/oraclevda /u01/app/oracle/product ext4 defaults,_netdev,nofail 0 2' | sudo tee -a /etc/fstab
sudo mount -a

# disable firewalld
sudo systemctl stop firewalld

# TODO add systemctl service for
# psft-appserver-APPDOM01.service               enabled
#sudo -H -u psadm2 bash -c '/u01/app/oracle/product/pt/ps_cfg_home/appserv/APPDOM01/psft-appserver-APPDOM01-domain-appdom01.sh start'
# psft-pia-WEBSERVER01.service                  enabled
#sudo -H -u psadm2 bash -c '/u01/app/oracle/product/pt/ps_cfg_home/webserv/WEBSERVER01/psft-pia-domain-webserver01.sh start'
# psft-prcs-PRCS01.service                      enabled
#sudo -H -u psadm2 bash -c '/u01/app/oracle/product/pt/ps_cfg_home/appserv/prcs/PRCS01/psft-prcs-PRCS01-domain-prcs01.sh start'
# psft-db.service                               enabled
sudo -H -u oracle2 bash -c 'cd /u01/app/oracle/product/db; ./psft-db-PSFTDB.sh start'

# install puppet, gems
cd /u01/app/oracle/product/home/psadm1/dpk_bits
sudo rpm -ih --force *.rpm
umask 0022
sudo /opt/puppetlabs/puppet/bin/gem install --local hiera-eyaml

# TODO - install psadmin_plus
sudo /opt/puppetlabs/puppet/bin/gem install psadmin_plus
# TODO - app and prcs domains needs re-config
sudo -H -u psadm2 bash -c '. ~/.bashrc; psa bounce'

# TODO - add to bashrc?
echo 'PATH=$PATH:/opt/puppetlabs/puppet/bin:/opt/puppetlabs/puppet/lib/ruby/gems/2.4.0/gems/hiera-eyaml-2.1.0/bin' | sudo tee -a /u01/app/oracle/product/home/psadm2/.bashrc

