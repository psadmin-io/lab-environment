#Requires -Version 5

<#PSScriptInfo

    .VERSION 1.0

    .AUTHOR psadmin.io

    .SYNOPSIS
        create guided-lab windows provisioning task

    .DESCRIPTION
        Create a scheduled task to run the provision-win script

    .EXAMPLE
        schedule-provision.ps1 -PASSWORD <password>

#>

#-----------------------------------------------------------[Parameters]----------------------------------------------------------

[CmdletBinding()]
Param(
  [String]$USER,  
  [String]$PASSWORD
)


#---------------------------------------------------------[Initialization]--------------------------------------------------------

# Valid values: "Stop", "Inquire", "Continue", "Suspend", "SilentlyContinue"
$ErrorActionPreference = "Stop"
$DebugPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"

#------------------------------------------------------------[Variables]----------------------------------------------------------

$DEBUG = "true"

#-----------------------------------------------------------[Functions]-----------------------------------------------------------

function schedule_provision() {
  Write-Host "[${env:COMPUTERNAME}] Creating provisioning scheduled task"
  $action = New-ScheduledTaskAction `
    -Execute 'Powershell.exe' `
    -Argument '-ExecutionPolicy Bypass -File "C:\temp\provision-win.ps1"' 
  
  $trigger =  New-ScheduledTaskTrigger `
    -At $((get-date).AddMinutes(1).ToString("HH:mm")) `
    -Once

  Register-ScheduledTask -Action $action `
    -Trigger $trigger `
    -TaskName "Provision" `
    -Description "Terraform Provisioner" `
    -User "${USER}" `
    -Password "${PASSWORD}"
}

# This was not reliable - scheduled task for 1 minute after creation instead
# function run_scheduled_task() {
#   Write-Host "[${env:COMPUTERNAME}] Executing provisioning script as a scheduled task"
#   get-scheduledtask -taskName "Provision" | start-scheduledtask
# }

#-----------------------------------------------------------[Execution]-----------------------------------------------------------

. schedule_provision