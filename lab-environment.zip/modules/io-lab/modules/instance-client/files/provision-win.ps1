#Requires -Version 5

<#PSScriptInfo

    .VERSION 1.0

    .AUTHOR psadmin.io

    .SYNOPSIS
        create guided-lab windows provisioning task

    .DESCRIPTION
        Create a scheduled task to run the provision-win script

    .EXAMPLE
        schedule-provision.ps1

#>

#-----------------------------------------------------------[Parameters]----------------------------------------------------------

[CmdletBinding()]
Param(
)


#---------------------------------------------------------[Initialization]--------------------------------------------------------

# Valid values: "Stop", "Inquire", "Continue", "Suspend", "SilentlyContinue"
$ErrorActionPreference = "Stop"
$DebugPreference = "SilentlyContinue"
$VerbosePreference = "SilentlyContinue"

#------------------------------------------------------------[Variables]----------------------------------------------------------

$DEBUG = "true"

#-----------------------------------------------------------[Functions]-----------------------------------------------------------

function upgrade_utilities(){
    Write-Output "[${env:COMPUTERNAME}] Upgrade Utilities"
    try {
        choco upgrade git -y
        choco upgrade firefox -y
        choco upgrade googlechrome -y
        choco upgrade vscode -y
        choco install putty.install -y
        choco install adobereader -y
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Upgrade Utilities"
    }
}

function fix_rubygems() {
    Write-Output "[${env:COMPUTERNAME}] Fix RubyGems"
    try {
        # https://gist.github.com/iversond/772e73257c4ca59a9e6137baa7288788
        $CACertFile = Join-Path -Path $ENV:AppData -ChildPath 'RubyCACert.pem'

        If (-Not (Test-Path -Path $CACertFile)) {  
            #"Downloading CA Cert bundle.."
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri 'https://curl.haxx.se/ca/cacert.pem' -UseBasicParsing -OutFile $CACertFile | Out-Null
        }

        # "Setting CA Certificate store set to $CACertFile.."
        $ENV:SSL_CERT_FILE = $CACertFile
        [System.Environment]::SetEnvironmentVariable('SSL_CERT_FILE',$CACertFile, [System.EnvironmentVariableTarget]::Machine)
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Fix RubyGems"
    }
}

function set_path_envvar() {
    Write-Output "[${env:COMPUTERNAME}] Adding puppet, gem, code and git to PATH"
    try {
        $env:PATH+=";C:\Program Files\Microsoft VS Code\bin"
        $env:PATH+=";C:\Program Files\Puppet Labs\Puppet\sys\ruby\bin;C:\Program Files\Git\bin;C:\Program Files\Puppet Labs\Puppet\bin\"
        [System.Environment]::SetEnvironmentVariable('PATH',$env:PATH, [System.EnvironmentVariableTarget]::Machine)
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Updating PATH"
    }
}

function set_nodenum_envvar() {
    Write-Output "[${env:COMPUTERNAME}] Setting NODENUM"
    try {
        $env:NODENUM = $env:NODENAME.substring($env:NODENAME.length-3,3)
        [System.Environment]::SetEnvironmentVariable('NODENUM',$env:NODENUM, [System.EnvironmentVariableTarget]::Machine)
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Setting NODENUM"
    }
}

function install_psadmin_plus() {
    Write-Output "[${env:COMPUTERNAME}] Install psadmin_plus Gem"
    try {
        gem install psadmin_plus
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Installing psadmin_plus Gem"
    }
}

function puppet_forge_ca() {
    Write-Output "[${env:COMPUTERNAME}] Download GeoTrustCA cert for Puppet Forge"
    try {
        iwr -uri https://www.geotrust.com/resources/root_certificates/certificates/GeoTrust_Global_CA.pem `
        -OutFile c:\temp\GeoTrustCA.pem 
    } catch {
            Write-Output "[${env:COMPUTERNAME}] [ERROR] Download GeoTrustCA cert"
        }
    Write-Output "[${env:COMPUTERNAME}]   Adding to Root Trust Store"
    try {
        certutil -v -addstore Root C:\temp\GeoTrustCA.pem
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Adding to Root Trust Store"
    }
}

function disable_av_scanning () {
    Write-Output "[${env:COMPUTERNAME}] Turn off Windows Defender real-time monitoring"
    try {
        set-mppreference -DisableRealtimeMonitoring $true
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Turning off Windows Defender"
    }
}

function remove_midtier_req() {
    Write-Output "[$env:COMPUTERNAME}] Remove 'midtier' check for pt_app_prcs"
    try {
        $pt_app_prcs_file = "C:\psft\dpk\puppet\production\modules\pt_role\manifests\pt_app_prcs.pp"
        $failline=" if `$env_type != 'midtier' {"
        (get-content $pt_app_prcs_file).replace($failline, '  if false {') | set-content $pt_app_prcs_file
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Removing 'midtier' from pt_app_prcs"
    }
}

function clone_sample_code_repo() {
    Write-Output "[${env:COMPTUERNAME}] Configure git repo for sample code"
    try {     
        set-location c:\psft\dpk\puppet
        Write-Output "[${env:COMPUTERNAME}] Initializing Git Repo for DPK Lab"
        git init
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Initializing Git Repo"
    }

    Write-Output "[${env:COMPUTERNAME}]   Adding remote origin "
    try {
        git remote add origin https://github.com/iversond/dpk-guided-lab-code.git
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Adding remote origin"
    }

    Write-Output "[${env:COMPUTERNAME}]   Git Pull Master "
    try { 
        git pull origin master
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Git Pull Master"
    }
}

function reconfigure_tux_domains() {
    start-service OracleOraDB12cHomeTNSListenerpsft_listener

    Write-Output "[${env:COMPUTERNAME}] Reconfigure Tuxedo Domains"
    Write-Output "[${env:COMPUTERNAME}]   App Server  "
    try { 
        psa bounce app
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Reconfigure App Server" 
    }
    Write-Output "[${env:COMPUTERNAME}]   Prcs Server  "
    try { 
        psa bounce prcs
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Reconfigure Prcs Server" 
    }
}

function configure_putty() {
    Write-Output "[${env:COMPUTERNAME}] Configure PuTTY"
    # Command to export PuTTY sessions
    # reg export HKEY_CURRENT_USER\Software\SimonTatham\PuTTY c:\temp\putty.reg
    try {
        reg import c:\\temp\\putty.reg
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Configure PuTTY"
    }
}

function configure_git_user(){
    Write-Output "[${env:COMPUTERNAME}] Configure Git User"
    try {
        git config --global user.email "psalab-$( $env:NODENAME.substring($env:NODENAME.length-3,3))@psadmin.io"
        git config --global user.name "psalab-$( $env:NODENAME.substring($env:NODENAME.length-3,3))"
        git config --global push.default simple
    } catch {
        Write-Output "[${env:COMPUTERNAME}] [ERROR] Configure Git User"
    }
}


#-----------------------------------------------------------[Execution]-----------------------------------------------------------

Start-Transcript -path C:\temp\provision-win.log -append

. upgrade_utilities
. fix_rubygems
. set_path_envvar
. set_nodenum_envvar
. install_psadmin_plus
. puppet_forge_ca
. disable_av_scanning
. remove_midtier_req
. clone_sample_code_repo
. reconfigure_tux_domains
. configure_putty
. configure_git_user

Stop-Transcript