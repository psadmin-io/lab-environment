#!/usr/bin/env bash
# shellcheck disable=2059,2154,2034,2155,2046,2086
#===============================================================================
# vim: softtabstop=2 shiftwidth=2 expandtab fenc=utf-8 spelllang=en ft=sh
#===============================================================================
#
#          FILE: provision-elklab.sh
#
#         USAGE: ./provision-elklab.sh
#
#   DESCRIPTION: Provisioning script for the ELK Lab
#
#===============================================================================

set -e          # Exit immediately on error
set -u          # Treat unset variables as an error
set -o pipefail # Prevent errors in a pipeline from being masked
IFS=$'\n\t'     # Set the internal field separator to a tab and newline


###############
#  Functions  #
###############

function echoinfo() {
  local GC="\033[1;32m"
  local EC="\033[0m"
  printf "${GC} ☆  INFO${EC}: %s${GC}\n" "$@";
}

function echodebug() {
  local BC="\033[1;34m"
  local EC="\033[0m"
  local GC="\033[1;32m"
  if [[ -n ${DEBUG+x} ]]; then
    printf "${BC} ★  DEBUG${EC}: %s${GC}\n" "$@";
  fi
}

function echoerror() {
  local RC="\033[1;31m"
  local EC="\033[0m"
  printf "${RC} ✖  ERROR${EC}: %s\n" "$@" 1>&2;
}

function install_software() {
  echoinfo "Install Software"
  sudo -S yum install git -y > /dev/null 2>&1
}

function clone_lab_code() {
  echoinfo "Cloning ELK Lab Code"
  cd /tmp
  git clone https://github.com/psadmin-io/elk-guided-lab-code.git > /dev/null 2>&1
}

function extract_log_files() {
  echoinfo "Extracting Log Files"

  cd /tmp/elk-guided-lab-code
  unzip logs.zip > /dev/null 2>&1
}

function configure_profile() {
  echoinfo "Configure Bash Profile"
  curl https://gist.githubusercontent.com/iversond/135fa17dec02c65bca8c8f0b5cbfa765/raw/97933cf4016418aedc1f37f80ac9f5cf491f7803/prompt.bashrc | tee -a /home/ec2-user/.bashrc
}

function open_firewall_ports(){
  echoinfo "Opening Firewall Ports"
  sudo -S iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 5601 -s 0.0.0.0/0 -j ACCEPT
  sudo -S iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 80 -s 0.0.0.0/0 -j ACCEPT
  sudo -S iptables -I INPUT -p tcp -m state --state NEW -m tcp --dport 5044 -s 0.0.0.0/0 -j ACCEPT
  sudo -S iptables -t nat -A PREROUTING -i eth0 -p tcp --dport 80 -j REDIRECT --to-port 5601
}

function set_timezone() {
  echoinfo "Set Timezone"
  sudo -S rm /etc/localtime
  sudo -S ln -s /usr/share/zoneinfo/America/Chicago /etc/localtime
}

# function set_user_password() {
#   echo -e "touch46?S!nk\ntouch46?S!nk" | passwd ec2-user
# }

########
# Main #
########

install_software
clone_lab_code
extract_log_files
configure_profile
open_firewall_ports
set_timezone