# Win Image cleanup

- [ ] Update windows patches around Sunday 4/26
- [ ] Update choco packages
- [ ] Clear recycle bin
- [ ] Set FireFox homepage (PS Login Page, Activity Guide)
- [ ] VS Code starting folder (c:\psft\dpk\puppet)
- [ ] Save default password VP1/VP1 in firefox
- [ ] Clean restart/ no unplanned message
- [ ] Place JMeter downloads? Install?